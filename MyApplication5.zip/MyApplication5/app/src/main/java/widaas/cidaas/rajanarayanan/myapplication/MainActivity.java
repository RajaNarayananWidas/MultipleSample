package widaas.cidaas.rajanarayanan.myapplication;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import widaas.cidaas.rajanarayanan.myandroidlibrary.AndroidCidaas;
import widaas.cidaas.rajanarayanan.mylibrary.SampleTesting;

public class MainActivity extends AppCompatActivity {
    AndroidCidaas androidCidaas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SampleTesting sampleTesting=new SampleTesting();
        androidCidaas=new AndroidCidaas(this);

        //Toast.makeText(this, ""+ sampleTesting.getName(), Toast.LENGTH_SHORT).show();

        //Toast.makeText(this, ""+androidCidaas.getGetClass(), Toast.LENGTH_SHORT).show();
    }


    public void buttonClick(View view)
    {
        androidCidaas.getLoginDetails();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        androidCidaas.onActivityResult(requestCode,resultCode,data);
    }
}
