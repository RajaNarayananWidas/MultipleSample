package widaas.cidaas.rajanarayanan.mylibrary;

public class SampleTesting {

    String name;


    public String getName()
    {
        name="S.Raja Narayanan";
        return name;
    }
}
